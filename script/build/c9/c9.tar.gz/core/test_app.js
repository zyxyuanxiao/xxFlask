var http = require('http');


http.createServer(function(req, res){

  res.writeHead( 200, { "content-Type" : 'text/plain' } )
  res.end('Hello world');

}).listen(7777, '0.0.0.0');
