Ruby, Ruby, Ruby, Ruby
Do you, do you, do you, do you
Know what you're doing, doing, to me