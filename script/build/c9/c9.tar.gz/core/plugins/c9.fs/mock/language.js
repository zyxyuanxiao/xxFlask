var language = "mind your language, young man"

var mom = {
	say: console.log
};

mom