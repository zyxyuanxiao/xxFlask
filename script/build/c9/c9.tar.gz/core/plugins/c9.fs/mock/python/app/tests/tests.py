from ..user.models import User

def test_user():
    return User()
