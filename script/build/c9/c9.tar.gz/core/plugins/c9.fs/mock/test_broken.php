<?php

this is bad php, obviously

?>